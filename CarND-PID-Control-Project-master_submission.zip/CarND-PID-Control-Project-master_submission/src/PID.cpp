#include "PID.h"
#include <iostream>
using namespace std;


PID::PID() {}

PID::~PID() {}

void PID::Init(double Kp, double Ki, double Kd) {
    this->Kp = Kp;
    this->Ki = Ki;
    this-> Kd = Kd;
    this->x = (double *) malloc(sizeof(double *));
    cout << "Initializing the PID " << endl;
}

void PID::UpdateError(double cte) {
    
}

double PID::TotalError() {
       return 0.0;
}


double PID::lowPassAveraging(double input, int points)
{
    double sum = 0;
    for(int i = points - 1; i < 0; --i)
    {
        this->x[i] = this->x[i-1];
        sum += this->x[i];
    }
    sum += input;
    this->x[0] = input;
    return sum/points;
}







